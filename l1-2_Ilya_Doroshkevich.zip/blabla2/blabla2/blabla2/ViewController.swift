//
//  ViewController.swift
//  blabla2
//
//  Created by Ilya Doroshkevitch on 13.06.2020.
//  Copyright © 2020 Ilya Doroshkevitch. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    
    @IBOutlet weak var scrollView: UIScrollView!
    
    @IBOutlet weak var loginTextField: UITextField!
    
    @IBOutlet weak var passwordTextField: UITextField!
    
    
    
    
    @IBAction func loginButtonPressed(_ sender: Any) {
        print(#function)
    }
    
    // check login and pswrd function
    override func shouldPerformSegue(withIdentifier identifier: String, sender: Any?) -> Bool {
        print(#function)
        let login = loginTextField.text
        let password = passwordTextField.text
        
        if login == "admin" && password == "12345" {return true}
        else {
            
            let alert = UIAlertController(title: "Error", message: "Wrong credentials", preferredStyle: .alert)
            let action = UIAlertAction(title: "OK", style: .cancel, handler: nil)
            alert.addAction(action)
            present(alert, animated: true, completion: nil)
            return false
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
    
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
    
    //подписка на нотификации
    NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillShow), name: UIResponder.keyboardWillShowNotification, object: nil)
    
    NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillHide), name: UIResponder.keyboardWillHideNotification, object: nil)
    
    
    }
    
    override func viewWillDisappear(_ animated: Bool) {
    
        //отписка от нотификаций при закрытии
        NotificationCenter.default.removeObserver(self)
    }
    
    
    @objc func keyboardWillShow(notification: Notification){
        print(#function)
        guard  let kbSize = notification.userInfo?[UIResponder.keyboardFrameEndUserInfoKey] as? CGRect else {
            return
        }
        scrollView.contentInset = UIEdgeInsets (top: 0, left: 0, bottom: kbSize.height, right: 0)
        
        }

    
    
    @objc func keyboardWillHide(notification: Notification){
        print(#function)
        scrollView.contentInset = .zero
        }
    
    // catch tap to hide keyboard
    @IBAction func scrollTapped(_ sender: UITapGestureRecognizer) {
           print(#function)
           scrollView.endEditing(true)
       }
       
    
    
    
    
}

