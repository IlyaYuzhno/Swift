//
//  cube.swift
//  snake
//
//  Created by Ilya Doroshkevitch on 09.06.2020.
//  Copyright © 2020 Ilya Doroshkevitch. All rights reserved.
//

import Foundation
import UIKit
import SpriteKit

class Cube: SKShapeNode {

    convenience init(position: CGPoint) {
        self.init()

        path = UIBezierPath(rect: CGRect(x: 0, y: 0, width: 50, height: 50)).cgPath
        fillColor = UIColor.red
        strokeColor = UIColor.black
        lineWidth = 5
        self.position = position


        self.physicsBody = SKPhysicsBody(rectangleOf: CGSize(width: 50, height: 50), center: CGPoint(x: 25, y: 25))

        self.physicsBody?.categoryBitMask = CollisionCategories​.Cube
    }
    
    }

    
    
    
    



