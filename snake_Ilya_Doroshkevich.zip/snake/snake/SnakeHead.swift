//
//  SnakeHead.swift
//  snake
//
//  Created by Ilya Doroshkevitch on 08.06.2020.
//  Copyright © 2020 Ilya Doroshkevitch. All rights reserved.
//

import Foundation
import UIKit
import SpriteKit

class ​SnakeHead​: SnakeBodyPart​ {
    override init(atPoint point: CGPoint) {
        super.init(atPoint:point)
// категория - голова
        self.physicsBody?.categoryBitMask = CollisionCategories​.SnakeHead
// пересекается с телом, яблоком и границей экрана
        self.physicsBody?.contactTestBitMask = CollisionCategories​.EdgeBody | CollisionCategories​.Apple | CollisionCategories​.Snake | CollisionCategories​.Cube
}
    required init?(coder aDecoder: NSCoder){fatalError("init(coder:) has not been implemented")}
}
