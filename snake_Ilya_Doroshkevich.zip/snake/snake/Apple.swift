//
//  Apple.swift
//  snake
//
//  Created by Ilya Doroshkevitch on 07.06.2020.
//  Copyright © 2020 Ilya Doroshkevitch. All rights reserved.
//

import Foundation
import UIKit
import SpriteKit


// Яблоко

    class Apple: SKShapeNode{
        //определяем, как оно будет отрисовываться
        convenience init(position: CGPoint) {
            self.init()
            //рисуем круг
            path = UIBezierPath(ovalIn: CGRect(x: 0, y: 0, width: 10, height: 10)).cgPath
            // заливаем красным
            fillColor = UIColor.yellow
            strokeColor = UIColor.systemPink
            lineWidth = 5
            self.position = position
            // Добавляем физическое тело, совпадающее с изображением яблока
            self.physicsBody = SKPhysicsBody(circleOfRadius: 8.0, center: CGPoint(x: 5, y: 5))
            // Категория - яблоко
            self.physicsBody?.categoryBitMask = CollisionCategories​.Apple
            
        }
    }
