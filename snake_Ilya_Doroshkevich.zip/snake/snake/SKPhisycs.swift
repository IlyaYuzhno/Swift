//
//  SKPhisycs.swift
//  snake
//
//  Created by Ilya Doroshkevitch on 08.06.2020.
//  Copyright © 2020 Ilya Doroshkevitch. All rights reserved.
//

import Foundation

